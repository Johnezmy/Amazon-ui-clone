const leftbtn = document.querySelector(".l-btn");
const rightbtn = document.querySelector(".r-btn");

rightbtn.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide");
    Comment.scrollLeft += 1100;
    even.preventDefault();
    });
leftbtn.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide");
    Comment.scrollLeft -= 1100;
    even.preventDefault();
    });

const leftbtn1 = document.querySelector(".btn-1b");
const rightbtn1 = document.querySelector(".btn-1a");

    rightbtn1.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-1");
    Comment.scrollLeft += 1100;
    even.preventDefault();
    });
    leftbtn1.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-1");
    Comment.scrollLeft -= 1100;
    even.preventDefault();
    });

const leftbtn2 = document.querySelector(".btn-2b");
const rightbtn2 = document.querySelector(".btn-2a");

    rightbtn2.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-2");
    Comment.scrollLeft += 1100;
    even.preventDefault();
    });
    leftbtn2.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-2");
    Comment.scrollLeft -= 1100;
    even.preventDefault();
    });

const leftbtn3 = document.querySelector(".btn-3b");
const rightbtn3 = document.querySelector(".btn-3a");

    rightbtn3.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-3");
    Comment.scrollLeft += 1100;
    even.preventDefault();
    });
    leftbtn3.addEventListener("click", function(event){
    console.log("dobne");
    const Comment = document.querySelector(".product-slide-3");
    Comment.scrollLeft -= 1100;
    even.preventDefault();
    });

const backtop = document.querySelector(".backtop");
backtop.addEventListener("click", ()=>{
    window.scrollTo({
    top: 0,
    behavior: "smooth"
       });
    })

const slidebar = document.querySelector(".slidebar");
const cross = document.querySelector(".fa-xmark");
const black = document.querySelector(".black");
const slidebtn = document.querySelector(".second-1");

    slidebtn.addEventListener("click", ()=> {
    slidebar.classList.add("active");
    cross.classList.add("active");
    black.classList.add("active");
    document.body.classList.add("stop-scroll");
    })
    cross.addEventListener("click", ()=> {
    slidebar.classList.remove("active");
    cross.classList.remove("active");
    black.classList.remove("active");
    document.body.classList.remove("stop-scroll");
    })

const sign = document.querySelector(".ac");
const tri = document.querySelector(".triangle");
const signin = document.querySelector(".hdn-sign");

    sign.addEventListener("click", ()=>{
    black.classList.toggle("active-1");
    signin.classList.toggle("active");
    tri.classList.toggle("active");
    })